// CameraToolKitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CameraToolKit.h"
#include "CameraToolKitDlg.h"
#include <vfw.h>
#include <winuser.h>
#include <Windows.h>
#include <stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCameraToolKitDlg dialog

CCameraToolKitDlg::CCameraToolKitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCameraToolKitDlg::IDD, pParent)
{
	m_hBmp=NULL;
	hWndC=NULL;
	PreViewFlag=false;
	RecordFlag=false;
	CaptureFlag=false;
	m_pDlg= new CSaveDlg(this);
	m_pVideoDlg = new CTimeDlg(this);

	//{{AFX_DATA_INIT(CCameraToolKitDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCameraToolKitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCameraToolKitDlg)
	DDX_Control(pDX, IDC_AVICAP, m_RecordButton);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCameraToolKitDlg, CDialog)
	//{{AFX_MSG_MAP(CCameraToolKitDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CAPFORMAT, OnCapformat)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	ON_BN_CLICKED(IDC_AVICAP, OnAvicap)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_HLP, OnHlp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCameraToolKitDlg message handlers

BOOL CCameraToolKitDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Create and Show the Splash window
	CSplashWnd::ShowSplashScreen(3000, IDB_MyLOGO, this);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	/*--------------------------------------------------------------*/
	//Iniatilize frame's details
	CStatic* pst=(CStatic*) GetDlgItem(IDC_STATIC_FRAME);
	pst->GetWindowRect(&m_rectFrame);
	ScreenToClient(&m_rectFrame);

	firstTime=true;
	/*--------------------------------------------------------------*/
	//Play sound
	i_Sound.PlaySoundFile("hi.wav");

	SetTimer(2,4000,NULL);//SetTimer to start previewing when program is loaded.

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCameraToolKitDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCameraToolKitDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if (IsIconic())
	{
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else if(!firstTime)
	{
		m_bmp.GetBitmap(&bm);
			
		m_bmp.GetBitmap(&bm);

		dcMem.DeleteDC();
		dcMem.CreateCompatibleDC(&dc);//����� �� ���� ���������
	    dcMem.SelectObject(&m_bmp);//����� ������ �������

		dc.StretchBlt(m_rectFrame.left,m_rectFrame.top,m_rectFrame.Width(),m_rectFrame.Height(),
				 &dcMem,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);		
	}
	else if(PreViewFlag)
	{
		m_bmp.GetBitmap(&bm);

		dcMem.DeleteDC();
		dcMem.CreateCompatibleDC(&dc);//����� �� ���� ���������
		dcMem.SelectObject(&m_bmp);//����� ������ �������

		dc.StretchBlt(m_rectFrame.left,m_rectFrame.top,m_rectFrame.Width(),m_rectFrame.Height(),
				&dcMem,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);
	}

	CDialog::OnPaint();
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCameraToolKitDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCameraToolKitDlg::OnCapformat() 
{
	hWndC = capCreateCaptureWindow("Capture Window", 
				WS_CHILD |/* WS_VISIBLE |*//*WS_THICKFRAME*/WS_DLGFRAME,
				m_rectFrame.TopLeft().x, m_rectFrame.TopLeft().y,
				m_rectFrame.Width(), m_rectFrame.Height(),
				GetSafeHwnd()/*hwndParent*/, 1);

	capDriverConnect (hWndC, 0);//connect to cammera's driver.
	capDlgVideoSource(hWndC);//pick the source camera.
	capDlgVideoFormat(hWndC); //to change the resolution.
	capDriverDisconnect(hWndC);	
}

void CCameraToolKitDlg::OnAbout() 
{
	//playing sound:
	i_Sound.PlaySoundFile("cheer.wav");

	//open dialog
	CAboutDlg *pDlg = new CAboutDlg;
    pDlg->DoModal();

    delete pDlg;
}

void CCameraToolKitDlg::OnOK() 
{
	//playing sound:
	i_Sound.PlaySoundFile("goodbye.wav");

	for(int i=0;i<100000000;i++);//delay for sound

	delete m_pDlg;

	CDialog::OnOK();
}

void CCameraToolKitDlg::OnPreview() 
{
	if(PreViewFlag)
	{
		CaptureFlag=false;
		SetTimer(1,66,NULL);
	}
	else if(!CaptureFlag && !PreViewFlag)
	{
		PreViewFlag=true;
		hWndC = capCreateCaptureWindow ( "Capture Window", 
			WS_CHILD /*| WS_VISIBLE /*| WS_THICKFRAME */|WS_DLGFRAME
			/*|WS_EX_DLGMODALFRAME*/,
			m_rectFrame.TopLeft().x, m_rectFrame.TopLeft().y,
			320, 240, 
			GetSafeHwnd()/*hwndParent*/, 11011);
		
		if(hWndC)
  			capDriverConnect (hWndC, 0); // 0 ->means default driver.
		else
		{
			AfxMessageBox("Error Cammera is not connected!");//error message box.
			exit(1);
		}

		SetTimer(1,66,NULL);
	}
}

void CCameraToolKitDlg::OnCapture() //=Snapshot
{
	if(PreViewFlag)
	{
		m_pDlg->popup=true;
		CaptureFlag=true;
		KillTimer(1); //kill preview timer.
	}

	firstTime=true;
	InvalidateRect(m_rectFrame,false);
	OnPaint();
}

void CCameraToolKitDlg::OnAvicap() 
{
	if(!CaptureFlag)
	{
		m_pVideoDlg->hWndC = capCreateCaptureWindow("Capture Window", 
				WS_CHILD |/* WS_VISIBLE |*//*WS_THICKFRAME*/WS_DLGFRAME,
				m_rectFrame.TopLeft().x, m_rectFrame.TopLeft().y,
				m_rectFrame.Width(), m_rectFrame.Height(),
				GetSafeHwnd()/*hwndParent*/, 1);
		

		if(!m_pVideoDlg->GetSafeHwnd())
			m_pVideoDlg->Create(IDD_TIMEQ);

	}
}

void CCameraToolKitDlg::OnSave() 
{
	if(CaptureFlag && m_hBmp)
	{
		CPaintDC dc(this); // device context for painting

		m_pDlg->dcMem.DeleteDC();
		m_pDlg->dcMem.CreateCompatibleDC(&dc);//����� �� ���� ���������
	    m_pDlg->dcMem.SelectObject(&m_bmp);//����� ������ �������

		m_pDlg->m_hBmp=m_hBmp;

		if(!m_pDlg->GetSafeHwnd() && m_pDlg->popup)
			m_pDlg->Create(IDD_SAVEPICTURE);
	}
}

void CCameraToolKitDlg::OnStop() 
{
	PreViewFlag=false;
	CaptureFlag=false;
	RecordFlag=false;
	firstTime=true;

	KillTimer(1);

	capCaptureStop(hWndC);
	capDriverDisconnect(hWndC);
	hWndC=NULL;
	
	m_hBmp=NULL;
	dcMem.Detach();

	//Stop playing sound:
	i_Sound.StopSoundFile();

	m_pDlg->popup=false;
	
	UpdateData(false);
	InvalidateRect(m_rectFrame);
	OnPaint();
}

void CCameraToolKitDlg::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent==1)// First Timer
	{
		if(!CaptureFlag && !RecordFlag && PreViewFlag)
		{
			capGrabFrame(hWndC);
			capEditCopy(hWndC);
			OpenClipboard();
			m_hBmp = (HBITMAP)::GetClipboardData(CF_BITMAP);
			CloseClipboard();
			m_bmp.Detach();
			m_bmp.Attach(m_hBmp);

			firstTime=false;

			InvalidateRect(m_rectFrame,false);
			OnPaint();
		}
	}
	if(nIDEvent==2)// Second
	{
		OnStop();
		OnPreview();
		KillTimer(2);
	}
	CDialog::OnTimer(nIDEvent);
}



void CCameraToolKitDlg::OnHlp() 
{
	CHelpDlg *pDlg = new CHelpDlg();
    pDlg->DoModal();

    delete pDlg;
}
