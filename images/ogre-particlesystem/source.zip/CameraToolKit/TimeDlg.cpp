// TimeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CameraToolKit.h"
#include "TimeDlg.h"
#include <vfw.h>
#include <winuser.h>
#include <Windows.h>
#include <stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimeDlg dialog


CTimeDlg::CTimeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTimeDlg::IDD, pParent)
{
	hWndC=NULL;    //capture window
	CaptureFlag=false;

	//{{AFX_DATA_INIT(CTimeDlg)
	m_Sec = 1;
	m_Sound = FALSE;
	//}}AFX_DATA_INIT
}


void CTimeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTimeDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Sec);
	DDX_Check(pDX, IDC_CHECK1, m_Sound);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTimeDlg, CDialog)
	//{{AFX_MSG_MAP(CTimeDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimeDlg message handlers

void CTimeDlg::OnOK() // = OnStart()
{
	UpdateData(true);//transfer data from the controlls
	
	RecordStreamVideo(m_Sec,m_Sound);	
}

void CTimeDlg::OnCancel() 
{
	DestroyWindow();
}

void CTimeDlg::RecordStreamVideo(int sec, BOOL sound)
{
	if(!CaptureFlag)
	{		
		char CapFileName[20]="C:MyVideo.avi";
	
		capCaptureGetSetup(hWndC,&m_pCapParm,sizeof(m_pCapParm));
		m_pCapParm.fLimitEnabled=true;
		m_pCapParm.wTimeLimit=sec;
		m_pCapParm.fCaptureAudio=sound;

		capDriverConnect(hWndC, 0);//connect to camera's driver.
		capFileSetCaptureFile(hWndC,CapFileName);
		
		capCaptureSetSetup(hWndC,&m_pCapParm,sizeof(m_pCapParm));
		capCaptureSequence(hWndC);//start recording.

		capCaptureStop(hWndC); //stop recording.
		capDriverDisconnect(hWndC);
		hWndC=NULL;

		AfxMessageBox("Your Video has filmed successfuly!\n It\'s in C:\\MyVideo.avi!",NULL);
		DestroyWindow();
	}
}

BOOL CTimeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CSpinButtonCtrl* pSp=(CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_Sec);
	pSp->SetRange(1,20);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

