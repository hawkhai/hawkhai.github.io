// SaveDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CameraToolKit.h"
#include "SaveDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSaveDlg dialog


CSaveDlg::CSaveDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSaveDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSaveDlg)
	m_path = _T("");
	//}}AFX_DATA_INIT
	popup=false;
	m_hBmp=NULL;
}


void CSaveDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSaveDlg)
	DDX_Text(pDX, IDC_PATH, m_path);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSaveDlg, CDialog)
	//{{AFX_MSG_MAP(CSaveDlg)
	ON_BN_CLICKED(IDC_NO2, OnNo)
	ON_BN_CLICKED(IDC_YES, OnYes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSaveDlg message handlers

void CSaveDlg::OnNo() 
{
	popup=true;
	DestroyWindow();
}


void CSaveDlg::OnYes() 
{
	popup=false;
	GetDlgItemText(IDC_PATH,m_path);//getting the written path from dialog.
	
	CString FileName;
	bool HasFullPath=false;
	int i;

	FileName=m_path;//getting user's string.
		
	for(i=0;i<FileName.GetLength();i++)
	{
		if(FileName[i]=='\\')//searching for back slesh.
			HasFullPath=true;
	}

	if(!HasFullPath)//if didn't give a full path.
	{
		FileName="C:\\";//saving in C:\ root.
		FileName+=m_path;
	}

	FileName+=".bmp";//end of file

	char file_str[30]={"."};
	for(i=0;i<FileName.GetLength();i++)
	{
		file_str[i]=FileName[i];
	}
	file_str[i]=NULL;
		
	SaveToFile(file_str,m_hBmp,dcMem);
	
	DestroyWindow();
}

HRESULT CSaveDlg::SaveToFile(LPTSTR pszFile, HBITMAP hBMP, HDC hDC)
{
    HANDLE hf;
    BITMAPFILEHEADER hdr;
    PBITMAPINFOHEADER pbih;
    LPBYTE lpBits;
    DWORD dwTotal;
    DWORD cb;
    BYTE *hp;
    DWORD dwTmp;
    BITMAP bmp;
    PBITMAPINFO pbi;
	WORD    cClrBits;

	if (!GetObject(hBMP, sizeof(BITMAP), (LPSTR)&bmp)) 
        return 0;

    cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel); 
    if (cClrBits == 1) 
        cClrBits = 1; 
    else if (cClrBits <= 4) 
        cClrBits = 4; 
    else if (cClrBits <= 8) 
        cClrBits = 8; 
    else if (cClrBits <= 16) 
        cClrBits = 16; 
    else if (cClrBits <= 24) 
        cClrBits = 24; 
    else cClrBits = 32; 
	
	if (cClrBits != 24)
	{
		pbi = (PBITMAPINFO) LocalAlloc(LPTR, sizeof(BITMAPINFOHEADER) +
			sizeof(RGBQUAD) * (1<< cClrBits)); 
	}
	else 
		pbi = (PBITMAPINFO) LocalAlloc(LPTR, sizeof(BITMAPINFOHEADER)); 
	
    pbi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER); 
    pbi->bmiHeader.biWidth = bmp.bmWidth; 
    pbi->bmiHeader.biHeight = bmp.bmHeight; 
    pbi->bmiHeader.biPlanes = bmp.bmPlanes; 
    pbi->bmiHeader.biBitCount = bmp.bmBitsPixel; 
    if (cClrBits < 24) 
        pbi->bmiHeader.biClrUsed = (1<<cClrBits); 
	
    pbi->bmiHeader.biCompression = BI_RGB; 
    pbi->bmiHeader.biSizeImage = ((pbi->bmiHeader.biWidth * cClrBits +31) & ~31) /8
		* pbi->bmiHeader.biHeight; 
	pbi->bmiHeader.biClrImportant = 0; 

    pbih = (PBITMAPINFOHEADER) pbi; 
    lpBits = (LPBYTE) GlobalAlloc(GMEM_FIXED, pbih->biSizeImage);
	
    if (!lpBits) 
		return E_FAIL;
	
    if (!GetDIBits(hDC, hBMP, 0, (WORD) pbih->biHeight, lpBits, pbi, 
        DIB_RGB_COLORS)) 
    {
		return E_FAIL;
    }
	
    hf = CreateFile(pszFile, 
		GENERIC_READ | GENERIC_WRITE, 
		(DWORD) 0, 
		NULL, 
		CREATE_ALWAYS, 
		FILE_ATTRIBUTE_NORMAL, 
		(HANDLE) NULL); 
    if (hf == INVALID_HANDLE_VALUE) 
		return E_FAIL;
    hdr.bfType = 0x4d42;
    hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
		pbih->biSize + pbih->biClrUsed 
		* sizeof(RGBQUAD) + pbih->biSizeImage); 
    hdr.bfReserved1 = 0; 
    hdr.bfReserved2 = 0; 
	
    hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
		pbih->biSize + pbih->biClrUsed 
		* sizeof (RGBQUAD);
	
    if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER), 
        (LPDWORD) &dwTmp,  NULL)) 
    {
		return E_FAIL;
    }
	
    if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFOHEADER) 
		+ pbih->biClrUsed * sizeof (RGBQUAD), 
		(LPDWORD) &dwTmp, ( NULL)) )
		return E_FAIL;
	
    dwTotal = cb = pbih->biSizeImage; 
    hp = lpBits; 
    if (!WriteFile(hf, (LPSTR) hp, (int) cb, (LPDWORD) &dwTmp,NULL)) 
		return E_FAIL;
	
	CloseHandle(hf);
    GlobalFree((HGLOBAL)lpBits);
	LocalFree(pbi);

	return S_OK;
}
