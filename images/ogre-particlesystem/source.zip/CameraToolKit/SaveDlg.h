#if !defined(AFX_SAVEDLG_H__A0D80126_5584_46AA_869F_69386367D4DB__INCLUDED_)
#define AFX_SAVEDLG_H__A0D80126_5584_46AA_869F_69386367D4DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SaveDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSaveDlg dialog

class CSaveDlg : public CDialog
{
// Construction
public:
	HRESULT SaveToFile(LPTSTR pszFile, HBITMAP hBMP, HDC hDC);
	CSaveDlg(CWnd* pParent = NULL);   // standard constructor
	bool popup;
	CDC dcMem;//virtual memory
	HBITMAP m_hBmp; //handle to bitmap
// Dialog Data
	//{{AFX_DATA(CSaveDlg)
	enum { IDD = IDD_SAVEPICTURE };
	CString	m_path;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSaveDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSaveDlg)
	afx_msg void OnNo();
	afx_msg void OnYes();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAVEDLG_H__A0D80126_5584_46AA_869F_69386367D4DB__INCLUDED_)
