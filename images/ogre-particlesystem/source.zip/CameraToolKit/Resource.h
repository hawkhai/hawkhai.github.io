//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CameraToolKit.rc
//
#define IDC_ABOUT                       2
#define IDC_HLP                         3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CAMERATOOLKIT_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDB_MyLOGO                      130
#define IDI_ICON1                       132
#define IDB_MyPic                       133
#define IDD_SAVEPICTURE                 134
#define IDD_HELPDLG                     135
#define IDD_TIMEQ                       136
#define IDC_STATIC_FRAME                1000
#define IDC_CAPFORMAT                   1002
#define IDC_PREVIEW                     1003
#define IDC_NO2                         1003
#define IDC_CAPTURE                     1004
#define IDC_YES                         1004
#define IDC_AVICAP                      1005
#define IDC_PATH                        1005
#define IDC_SAVE                        1006
#define IDC_STOP                        1007
#define IDC_EDIT1                       1007
#define IDC_SPIN_Sec                    1009
#define IDC_CHECK1                      1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
