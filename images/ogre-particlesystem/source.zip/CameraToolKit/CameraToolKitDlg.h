// CameraToolKitDlg.h : header file
//

#if !defined(AFX_CAMERATOOLKITDLG_H__155E6657_0E8A_4A2C_93FD_92DCE25E7264__INCLUDED_)
#define AFX_CAMERATOOLKITDLG_H__155E6657_0E8A_4A2C_93FD_92DCE25E7264__INCLUDED_

#include "SplashWnd.h"
#include "StdAfx.h"
#include "cSound.h"
#include "SaveDlg.h"
#include "HelpDlg.h"
#include "TimeDlg.h"
#include <math.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIZEPic 500
/////////////////////////////////////////////////////////////////////////////
// CCameraToolKitDlg dialog

class CCameraToolKitDlg : public CDialog
{
// Construction
public:
	CTimeDlg* m_pVideoDlg;
	CCameraToolKitDlg(CWnd* pParent = NULL);	// standard constructor
	HWND hWndC;    //capture window
	CDC dcMem;//virtual memory
	HBITMAP m_hBmp; //handle to bitmap

// Dialog Data
	//{{AFX_DATA(CCameraToolKitDlg)
	enum { IDD = IDD_CAMERATOOLKIT_DIALOG };
	CButton	m_RecordButton;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCameraToolKitDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CSaveDlg* m_pDlg;
	HICON m_hIcon;	
	BITMAP bm; //bitmap struct
	CBitmap m_bmp; //bitmap object
	CRect m_rectFrame; //capture frame inside main window
	CString strFilename; //string
	bool firstTime;
	bool PreViewFlag;
	bool CaptureFlag;
	bool RecordFlag;
	cSound i_Sound; //sound device conector
	COLORREF m_pic[SIZEPic][SIZEPic];

	// Generated message map functions
	//{{AFX_MSG(CCameraToolKitDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCapformat();
	afx_msg void OnAbout();
	virtual void OnOK();
	afx_msg void OnPreview();
	afx_msg void OnCapture();
	afx_msg void OnAvicap();
	afx_msg void OnSave();
	afx_msg void OnStop();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnHlp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAMERATOOLKITDLG_H__155E6657_0E8A_4A2C_93FD_92DCE25E7264__INCLUDED_)
