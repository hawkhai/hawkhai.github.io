/*
* This file was automatically generated running
* 'configure.py --os=android --cc=clang --cpu=arm --minimized-build --amalgamation --disable-shared-library --enable-modules=aes,sha2_32,md5,cbc,filters,zlib --without-os-feature=getauxval'
*
* Target
*  - Compiler: D:\Android\Sdk\ndk\22.0.7026061\toolchains\llvm\prebuilt\windows-x86_64\bin\armv7a-linux-androideabi28-clang++.cmd -fstack-protector -pthread -std=c++11 -D_REENTRANT -O3
*  - Arch: arm32
*  - OS: android
*/
#ifndef botan_all_android_clang_arm32
#define botan_all_android_clang_arm32

#define BOTAN_VERSION_MAJOR 2
#define BOTAN_VERSION_MINOR 13
#define BOTAN_VERSION_PATCH 0
#define BOTAN_VERSION_DATESTAMP 0

#define BOTAN_VERSION_RELEASE_TYPE "unreleased"

#define BOTAN_VERSION_VC_REVISION "unknown"

#define BOTAN_DISTRIBUTION_INFO "unspecified"

/* How many bits per limb in a BigInt */
#define BOTAN_MP_WORD_BITS 32

#define BOTAN_INSTALL_PREFIX R"(/usr/local)"
#define BOTAN_INSTALL_HEADER_DIR R"(include/botan-2)"
#define BOTAN_INSTALL_LIB_DIR R"(/usr/local\lib)"
#define BOTAN_LIB_LINK "-lz"
#define BOTAN_LINK_FLAGS "-fstack-protector -pthread"

#ifndef BOTAN_DLL
  #define BOTAN_DLL 
#endif

/* Target identification and feature test macros */

#define BOTAN_TARGET_OS_IS_ANDROID

#define BOTAN_TARGET_OS_HAS_ARC4RANDOM
#define BOTAN_TARGET_OS_HAS_CLOCK_GETTIME
#define BOTAN_TARGET_OS_HAS_DEV_RANDOM
#define BOTAN_TARGET_OS_HAS_FILESYSTEM
//#define BOTAN_TARGET_OS_HAS_GETAUXVAL
#define BOTAN_TARGET_OS_HAS_POSIX1
#define BOTAN_TARGET_OS_HAS_POSIX_MLOCK
#define BOTAN_TARGET_OS_HAS_SOCKETS
#define BOTAN_TARGET_OS_HAS_THREAD_LOCAL
#define BOTAN_TARGET_OS_HAS_THREADS

#define BOTAN_BUILD_COMPILER_IS_CLANG

#define BOTAN_TARGET_ARCH_IS_ARM32
#define BOTAN_TARGET_CPU_IS_LITTLE_ENDIAN
#define BOTAN_TARGET_CPU_IS_ARM_FAMILY

#define BOTAN_TARGET_SUPPORTS_NEON

#endif
