## 文档

<https://sunocean.life/blog/blog/2020/10/24/dip-image-marathon>
